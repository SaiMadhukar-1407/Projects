Sreenidhi-Placement-Management-System
=====================================

Developing a site for recruiting the eligible candidates who are already enrolled their names in the Placement Office and a completely interactive site for the students to enhance their technical and communication skills and to be easily placed in companies

MODULES

1.Creating GUI Interfaces for Recruiter,Student and Admin and handling inner logic of those  three actors of the system.

2.Generating Reports of Online marks,eligible students for writing online test,selected students for interview and final selected students.Sending email  to selected students and uploading files.

3.Online Test module

4.Providing practice sets for students and outsiders who visit the website

5.Creating a  Discussion Forum for handling student queries and other information which helps students in preparing for placements. 

6.Send an SMS to final selected students.