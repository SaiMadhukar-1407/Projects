

package java.com.bean;


public class user {
private String password;
private String username;
private String company;
private String rcname;
private String button;
public void setA(String uname)
{
    username=uname;
}
public String getA()
{
    return username;
}
public void setB(String pwd)
{
    password=pwd;
}
public String getB()
{
    return password;
}
public void setC(String company)
{
    this.company=company;
}
public String getC()
{
    return company;
}
public void setD(String rcname)
{
   this.rcname=rcname; 
}
public String getD()
{
    return rcname;
}
public void setE(String button)
{
    this.button=button;
}
public String getE()
{
    return button;
}
}

